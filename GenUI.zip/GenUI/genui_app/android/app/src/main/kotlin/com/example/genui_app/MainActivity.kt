package com.example.genui_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
