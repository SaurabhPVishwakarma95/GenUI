// import 'package:firebase_ai/firebase_ai.dart';
import 'package:flutter/material.dart';
import 'package:genui/genui.dart';
// import 'package:genui_firebase_ai/genui_firebase_ai.dart';
import 'package:genui_google_generative_ai/genui_google_generative_ai.dart';

class GenUIScreen extends StatefulWidget {
  const GenUIScreen({super.key});

  @override
  State<GenUIScreen> createState() => _GenUIScreenState();
}

class _GenUIScreenState extends State<GenUIScreen> {
  late final A2uiMessageProcessor _messageProcessor;
  late final GoogleGenerativeAiContentGenerator _generator;
  late final GenUiConversation _conversation;
  final List<String> _activeSurfaceIds = [];
  final TextEditingController _inputController = TextEditingController();

  @override
  void initState() {
    super.initState();

    // 1. Define the Catalog (available widgets for the AI)
    final catalog = CoreCatalogItems.asCatalog();

    // 2. Initialize the Message Processor
    _messageProcessor = A2uiMessageProcessor(catalogs: [catalog]);

    _generator = GoogleGenerativeAiContentGenerator(
      catalog: catalog,
      systemInstruction: '''
        You are a helpful assistant. 
        ALWAYS respond using the available UI widgets. 
      ''',
      modelName: 'models/gemini-2.5-flash',
      apiKey: 'AIzaSyCAWPKpqTFh5lE1UDOKnXs1-aK6eyIE478', // Get from aistudio.google.com
    );

    _conversation = GenUiConversation(
      contentGenerator: _generator,
      a2uiMessageProcessor: _messageProcessor,
      onSurfaceAdded: (id) {
        debugPrint('SURFACE ADDED: ${id.surfaceId}'); // Check your logs!
        setState(() => _activeSurfaceIds.add(id.surfaceId));
      },
      // ADD THIS to see if the AI is ignoring your "No plain text" rule
      onTextResponse: (text) {
        debugPrint('AI TEXT RESPONSE: $text');
      },
    );

    debugPrint("Data: $_activeSurfaceIds");
}

  void _handleSend() {
    final text = _inputController.text; // Store it first!
    debugPrint('Sending to AI: $text'); // Check if this prints
    if (text.isNotEmpty) {
      _inputController.clear(); 
      _conversation.sendRequest(AiTextMessage.text(text));
    }
  }

@override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(title: const Text('GenUI Agent App')),
    body: Column(
      children: [
        Expanded(
          child: ListView.builder(
            itemCount: _activeSurfaceIds.length,
            itemBuilder: (context, index) {
              return GenUiSurface(
                host: _conversation.host,
                surfaceId: _activeSurfaceIds[index],
                // Use a Spinner so you know when the AI is working
                defaultBuilder: (context) => const Center(
                  child: Padding(
                    padding: EdgeInsets.all(20.0),
                    child: CircularProgressIndicator(),
                  ),
                ),
              );
            },
          ),
        ),
        // Input Area
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(child: TextField(controller: _inputController)),
                IconButton(onPressed: _handleSend, icon: const Icon(Icons.send))
              ],
            ),
          ),
        ),        
      ],
    ),
  );
}
}
