import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:genui_app/gen_ui_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyD3SRPAfgly9YjsKTQZxFoqjqdl00Q_X14", 
      appId: "1:45210455445:android:ca9ea0f286da09e6213a9c", 
      messagingSenderId: "45210455445", 
      projectId: "genui-4a470",
      // storageBucket: 'YOUR_BUCKET', // Optional
    ),
  );  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: .fromSeed(seedColor: Colors.deepPurple),
      ),
      home: const GenUIScreen(),
    );
  }
}

